/* hakpala
 * Henry Akpala: 
 * Added a second constructor with Expression argument
 */

package Triangle.AbstractSyntaxTrees;

import Triangle.SyntacticAnalyzer.SourcePosition;

public class VarDeclarationExpression extends VarDeclaration {
	
	
	public  VarDeclarationExpression (Identifier iAST, TypeDenoter tAST, Expression eAST,
		SourcePosition thePosition) {
	super (iAST, tAST, thePosition);
	E = eAST;
}


public Object visit(Visitor v, Object o) {
    return v.visitVarDeclarationExpression(this, o);
  }

  public Expression E;
}


